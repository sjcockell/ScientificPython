import os, shutil, webbrowser
from PIL import Image
import PIL.ImageOps

def openSGD(queryGene):
    '''Open the SGD webpage for the query gene'''
    URL="http://www.yeastgenome.org/locus/"+queryGene+"/overview"
    webbrowser.open_new_tab(URL)

def relevantFiles(queryGene,allfiles):
    '''Get filenames containing queryGene from allfiles list'''
    queryfiles=[]
    for x in allfiles:
        # Don't add any directory names
        if queryGene in x and queryGene!=x:
            queryfiles.append(x)
    return(queryfiles)

def savePreviews(directory,im,sclup=10):
    '''Edit image and save different versions'''
    im.save(os.path.join(queryGene,"Horizontal.jpg"))
    rotate=im.transpose(Image.ROTATE_90)
    rotate.save(os.path.join(queryGene,"Vertical.jpg"))
    invert=PIL.ImageOps.invert(im)
    invert.save(os.path.join(queryGene,"Inverted.jpg"))
    enlarge=im.resize((wmax*len(imlist)*sclup,hmax*sclup),Image.ANTIALIAS)
    enlarge.save(os.path.join(queryGene,"Enlarged.jpg"))

# Get current directory
currdir= os.getcwd()
# Get list of files in current directory
allfiles=os.listdir(currdir)

for queryGene in ["EXO1","HIS2","HIS3","HIS4","HIS5"]:
    openSGD(queryGene)
    queryfiles=relevantFiles(queryGene,allfiles)
    print(queryGene+" files in directory:")
    for q in queryfiles:
        print(q)

    # Let's create a new directory (if it doesn't exist) and put the images in it
    if queryGene not in allfiles:
        os.mkdir(queryGene)
        os.mkdir(os.path.join(queryGene,"Tiles"))
    # Copy the images into the correct folder
    for x in queryfiles:
        shutil.copy(x,os.path.join(queryGene,"Tiles",x))

    # Open the image files
    imlist=[Image.open(qf) for qf in queryfiles]

    # Get image sizes
    wlist=[im.size[0] for im in imlist]
    hlist=[im.size[1] for im in imlist]
    wmax=max(wlist)
    hmax=max(hlist)

    # Create an empty image to paste into
    blank=Image.new("RGB",(wmax*len(imlist),hmax),color=0)
    # Space images out evenly and paste into blank image
    for i,im in enumerate(imlist):
        blank.paste(im,(wmax*i,0))

    savePreviews(queryGene,blank)
